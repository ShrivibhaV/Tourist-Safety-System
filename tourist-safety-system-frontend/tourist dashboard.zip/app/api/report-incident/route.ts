export async function POST(request: Request) {
  const { title, description, location, severity } = await request.json()

  const incidentId = `INC-${Date.now()}`
  console.log(`[Report] New incident: ${incidentId}`)

  return Response.json({
    success: true,
    incidentId: incidentId,
    message: "Incident reported successfully",
    severity: severity,
    timestamp: new Date().toISOString(),
  })
}
