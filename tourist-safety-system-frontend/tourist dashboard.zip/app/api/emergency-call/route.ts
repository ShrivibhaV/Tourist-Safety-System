export async function POST(request: Request) {
  const { service, number } = await request.json()

  console.log(`[Emergency] Calling ${service} at ${number}`)

  return Response.json({
    success: true,
    message: `Emergency call to ${service} initiated`,
    number: number,
    timestamp: new Date().toISOString(),
  })
}
