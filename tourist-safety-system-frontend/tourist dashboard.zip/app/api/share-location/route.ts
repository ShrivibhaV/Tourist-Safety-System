export async function POST(request: Request) {
  const { latitude, longitude, contacts } = await request.json()

  console.log(`[Location] Sharing location (${latitude}, ${longitude}) with ${contacts.length} contacts`)

  return Response.json({
    success: true,
    message: "Location shared with emergency contacts",
    location: { latitude, longitude },
    contactsNotified: contacts.length,
    timestamp: new Date().toISOString(),
  })
}
