import { Header } from "@/components/header"
import { StatsCards } from "@/components/stats-cards"
import { QuickActions } from "@/components/quick-actions"
import { SOSButton } from "@/components/sos-button"
import { EmergencyServices } from "@/components/emergency-services"
import { Resources } from "@/components/resources"
import { SafetyTips } from "@/components/safety-tips"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <Header />
        <StatsCards />
        <QuickActions />
        <SOSButton />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-12">
          <div className="lg:col-span-2">
            <EmergencyServices />
          </div>
          <div>
            <Resources />
          </div>
        </div>

        <SafetyTips />
      </div>
    </main>
  )
}
