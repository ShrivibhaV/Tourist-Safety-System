export function Header() {
  return (
    <div className="mb-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-2">Tourist Safety Dashboard</h1>
      <p className="text-gray-600">Welcome to India - Stay safe and enjoy your journey</p>
    </div>
  )
}
