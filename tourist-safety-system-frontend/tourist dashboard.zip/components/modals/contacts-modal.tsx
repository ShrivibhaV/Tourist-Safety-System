"use client"

import { X, Phone, Plus, Trash2 } from "lucide-react"
import { useState, useEffect } from "react"

interface Contact {
  id: string
  name: string
  phone: string
}

interface ContactsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ContactsModal({ open, onOpenChange }: ContactsModalProps) {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [newName, setNewName] = useState("")
  const [newPhone, setNewPhone] = useState("")

  useEffect(() => {
    const saved = localStorage.getItem("emergencyContacts")
    if (saved) {
      setContacts(JSON.parse(saved))
    }
  }, [])

  const addContact = () => {
    if (newName && newPhone) {
      const contact = {
        id: Date.now().toString(),
        name: newName,
        phone: newPhone,
      }
      const updated = [...contacts, contact]
      setContacts(updated)
      localStorage.setItem("emergencyContacts", JSON.stringify(updated))
      setNewName("")
      setNewPhone("")
    }
  }

  const deleteContact = (id: string) => {
    const updated = contacts.filter((c) => c.id !== id)
    setContacts(updated)
    localStorage.setItem("emergencyContacts", JSON.stringify(updated))
  }

  const callContact = (phone: string) => {
    window.location.href = `tel:${phone}`
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-96 overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold text-gray-900">Emergency Contacts</h2>
          <button onClick={() => onOpenChange(false)} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="space-y-2">
            <input
              type="text"
              placeholder="Contact name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            />
            <input
              type="tel"
              placeholder="Phone number"
              value={newPhone}
              onChange={(e) => setNewPhone(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            />
            <button
              onClick={addContact}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Contact
            </button>
          </div>

          <div className="space-y-2">
            {contacts.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No contacts added yet</p>
            ) : (
              contacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{contact.name}</p>
                    <p className="text-sm text-gray-600">{contact.phone}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => callContact(contact.phone)}
                      className="p-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                      <Phone className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteContact(contact.id)}
                      className="p-2 bg-red-600 text-white rounded hover:bg-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
