"use client"

import { X, MapPin } from "lucide-react"

interface NearbyPlacesProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function NearbyPlaces({ open, onOpenChange }: NearbyPlacesProps) {
  const places = [
    { name: "Police Station", distance: "0.5 km", icon: "🚔" },
    { name: "Hospital", distance: "1.2 km", icon: "🏥" },
    { name: "Tourist Information Center", distance: "0.8 km", icon: "ℹ️" },
    { name: "Safe Cafe", distance: "0.3 km", icon: "☕" },
    { name: "Hotel", distance: "0.6 km", icon: "🏨" },
    { name: "ATM", distance: "0.4 km", icon: "🏧" },
  ]

  const openMaps = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords
        window.open(`https://maps.google.com/?q=${latitude},${longitude}`, "_blank")
      })
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-96 overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b sticky top-0 bg-white">
          <h2 className="text-xl font-bold text-gray-900">Nearby Safe Places</h2>
          <button onClick={() => onOpenChange(false)} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-3">
          {places.map((place, index) => (
            <div
              key={index}
              className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <span className="text-2xl">{place.icon}</span>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{place.name}</p>
                <p className="text-sm text-gray-600 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {place.distance}
                </p>
              </div>
            </div>
          ))}

          <button
            onClick={openMaps}
            className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium"
          >
            Open in Google Maps
          </button>
        </div>
      </div>
    </div>
  )
}
