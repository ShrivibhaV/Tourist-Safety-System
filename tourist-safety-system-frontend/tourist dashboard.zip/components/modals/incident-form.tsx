"use client"

import { X, Send } from "lucide-react"
import { useState } from "react"

interface IncidentFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function IncidentForm({ open, onOpenChange }: IncidentFormProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [severity, setSeverity] = useState("medium")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = () => {
    if (title && description) {
      const incident = {
        id: Date.now().toString(),
        title,
        description,
        severity,
        timestamp: new Date().toLocaleString(),
      }

      const incidents = JSON.parse(localStorage.getItem("incidents") || "[]")
      incidents.push(incident)
      localStorage.setItem("incidents", JSON.stringify(incidents))

      setSubmitted(true)
      setTimeout(() => {
        setTitle("")
        setDescription("")
        setSeverity("medium")
        setSubmitted(false)
        onOpenChange(false)
      }, 2000)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold text-gray-900">Report Incident</h2>
          <button onClick={() => onOpenChange(false)} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-6 text-center">
            <div className="text-4xl mb-4">✓</div>
            <p className="text-green-600 font-semibold">Incident reported successfully!</p>
          </div>
        ) : (
          <div className="p-6 space-y-4">
            <input
              type="text"
              placeholder="Incident title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            />
            <textarea
              placeholder="Describe what happened"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            />
            <select
              value={severity}
              onChange={(e) => setSeverity(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            >
              <option value="low">Low Severity</option>
              <option value="medium">Medium Severity</option>
              <option value="high">High Severity</option>
            </select>
            <button
              onClick={handleSubmit}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              Submit Report
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
