"use client"

import { MapPin, Shield, AlertCircle, FileText } from "lucide-react"
import { useEffect, useState } from "react"

interface LocationData {
  latitude: number
  longitude: number
  city: string
}

export function StatsCards() {
  const [location, setLocation] = useState("New Delhi, India")
  const [coords, setCoords] = useState<LocationData | null>(null)
  const [safetyScore, setSafetyScore] = useState(85)
  const [nearbyAlerts, setNearbyAlerts] = useState(2)
  const [myReports, setMyReports] = useState(3)

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setCoords({ latitude, longitude, city: "Current Location" })
          // Store in localStorage for persistence
          localStorage.setItem("userLocation", JSON.stringify({ latitude, longitude }))
        },
        () => {
          // Fallback to New Delhi
          setCoords({ latitude: 28.6139, longitude: 77.209, city: "New Delhi" })
        },
      )
    }

    // Load reports from localStorage
    const savedReports = localStorage.getItem("incidents")
    if (savedReports) {
      setMyReports(JSON.parse(savedReports).length)
    }
  }, [])

  const stats = [
    {
      label: "Current Location",
      value: location,
      icon: MapPin,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      label: "Safety Score",
      value: safetyScore,
      subtext: "Excellent safety level",
      icon: Shield,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      label: "Nearby Alerts",
      value: nearbyAlerts,
      subtext: "Active in your area",
      icon: AlertCircle,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
    {
      label: "My Reports",
      value: myReports,
      subtext: "Total incidents reported",
      icon: FileText,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, index) => {
        const Icon = stat.icon
        return (
          <div
            key={index}
            className={`${stat.bgColor} rounded-xl p-6 border border-gray-200 hover:border-blue-300 transition-all hover:shadow-md`}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                {stat.subtext && <p className="text-xs text-gray-500 mt-1">{stat.subtext}</p>}
              </div>
              <Icon className={`w-6 h-6 ${stat.color}`} />
            </div>
          </div>
        )
      })}
    </div>
  )
}
