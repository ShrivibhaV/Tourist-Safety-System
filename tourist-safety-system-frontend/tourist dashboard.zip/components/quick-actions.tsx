"use client"

import { Share2, Users, AlertTriangle, MapPin } from "lucide-react"
import { useState } from "react"
import { ContactsModal } from "./modals/contacts-modal"
import { IncidentForm } from "./modals/incident-form"
import { NearbyPlaces } from "./modals/nearby-places"

export function QuickActions() {
  const [showContacts, setShowContacts] = useState(false)
  const [showIncident, setShowIncident] = useState(false)
  const [showNearby, setShowNearby] = useState(false)
  const [notification, setNotification] = useState<string | null>(null)

  const handleShareLocation = async () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords
        const mapsUrl = `https://maps.google.com/?q=${latitude},${longitude}`
        const text = `My location: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`

        if (navigator.share) {
          navigator.share({
            title: "My Location",
            text: text,
            url: mapsUrl,
          })
        } else {
          // Fallback: copy to clipboard
          navigator.clipboard.writeText(text)
          setNotification("Location copied to clipboard!")
          setTimeout(() => setNotification(null), 3000)
        }
      })
    }
  }

  const actions = [
    {
      label: "Share Location",
      icon: Share2,
      action: handleShareLocation,
      color: "from-blue-500 to-blue-600",
    },
    {
      label: "My Contacts",
      icon: Users,
      action: () => setShowContacts(true),
      color: "from-purple-500 to-purple-600",
    },
    {
      label: "Report Incident",
      icon: AlertTriangle,
      action: () => setShowIncident(true),
      color: "from-red-500 to-red-600",
    },
    {
      label: "Find Nearby",
      icon: MapPin,
      action: () => setShowNearby(true),
      color: "from-green-500 to-green-600",
    },
  ]

  return (
    <>
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {actions.map((action, index) => {
            const Icon = action.icon
            return (
              <button
                key={index}
                onClick={action.action}
                className={`bg-gradient-to-r ${action.color} text-white rounded-xl p-4 hover:shadow-lg transition-all transform hover:scale-105 flex items-center justify-center gap-3 font-medium`}
              >
                <Icon className="w-5 h-5" />
                {action.label}
              </button>
            )
          })}
        </div>
      </div>

      {notification && (
        <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg animate-pulse">
          {notification}
        </div>
      )}

      <ContactsModal open={showContacts} onOpenChange={setShowContacts} />
      <IncidentForm open={showIncident} onOpenChange={setShowIncident} />
      <NearbyPlaces open={showNearby} onOpenChange={setShowNearby} />
    </>
  )
}
